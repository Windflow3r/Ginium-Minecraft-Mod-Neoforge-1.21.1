package net.windflow3r.ginium.item;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;

public class GiniumFoodProperties {

    // =========================================================
    // ROSPOWDER - SWEET / ENERGETIC / NETHER
    // =========================================================

    public static final FoodProperties ROSPOWDER =
            new FoodProperties.Builder()
                    .nutrition(3)
                    .saturationModifier(0.5f)
                    .alwaysEdible()

                    // Positive - energetic / Nether
                    .effect(() -> new MobEffectInstance(
                                    MobEffects.SATURATION,
                                    200 + (int) (Math.random() * 401)),
                            0.10f + (float) (Math.random() * 0.51f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.MOVEMENT_SPEED,
                                    200 + (int) (Math.random() * 401)),
                            0.10f + (float) (Math.random() * 0.51f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.JUMP,
                                    200 + (int) (Math.random() * 401)),
                            0.10f + (float) (Math.random() * 0.51f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.FIRE_RESISTANCE,
                                    200 + (int) (Math.random() * 401)),
                            0.10f + (float) (Math.random() * 0.51f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.REGENERATION,
                                    200 + (int) (Math.random() * 401)),
                            0.10f + (float) (Math.random() * 0.51f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.DAMAGE_BOOST,
                                    200 + (int) (Math.random() * 401)),
                            0.10f + (float) (Math.random() * 0.51f))

                    // Negative - unstable
                    .effect(() -> new MobEffectInstance(
                                    MobEffects.HUNGER,
                                    100 + (int) (Math.random() * 201)),
                            0.10f + (float) (Math.random() * 0.41f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.WEAKNESS,
                                    100 + (int) (Math.random() * 201)),
                            0.10f + (float) (Math.random() * 0.71f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.POISON,
                                    100 + (int) (Math.random() * 201)),
                            0.10f + (float) (Math.random() * 0.51f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.DARKNESS,
                                    100 + (int) (Math.random() * 201)),
                            0.10f + (float) (Math.random() * 0.61f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.CONFUSION,
                                    100 + (int) (Math.random() * 201)),
                            0.10f + (float) (Math.random() * 0.41f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.GLOWING,
                                    100 + (int) (Math.random() * 201)),
                            0.05f)

                    .build();


    // =========================================================
    // NYLIPOWDER - DARK / EVIL / END
    // =========================================================

    public static final FoodProperties NYLIPOWDER =
            new FoodProperties.Builder()
                    .nutrition(3)
                    .saturationModifier(0.5f)
                    .alwaysEdible()

                    // Positive - strange / End
                    .effect(() -> new MobEffectInstance(
                                    MobEffects.INVISIBILITY,
                                    200 + (int) (Math.random() * 401)),
                            0.10f + (float) (Math.random() * 0.51f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.NIGHT_VISION,
                                    200 + (int) (Math.random() * 401)),
                            0.10f + (float) (Math.random() * 0.51f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.LEVITATION,
                                    100 + (int) (Math.random() * 201)),
                            0.10f + (float) (Math.random() * 0.61f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.SLOW_FALLING,
                                    200 + (int) (Math.random() * 401)),
                            0.10f + (float) (Math.random() * 0.51f))

                    // Negative - dark / unstable
                    .effect(() -> new MobEffectInstance(
                                    MobEffects.DARKNESS,
                                    100 + (int) (Math.random() * 201)),
                            0.10f + (float) (Math.random() * 0.61f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.CONFUSION,
                                    100 + (int) (Math.random() * 201)),
                            0.10f + (float) (Math.random() * 0.41f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.WEAKNESS,
                                    100 + (int) (Math.random() * 201)),
                            0.10f + (float) (Math.random() * 0.61f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.GLOWING,
                                    100 + (int) (Math.random() * 201)),
                            0.05f)

                    .build();


    // =========================================================
    // GINPOWDER - CLEVER / CALM / GROUNDED
    // =========================================================

    public static final FoodProperties GINPOWDER =
            new FoodProperties.Builder()
                    .nutrition(3)
                    .saturationModifier(0.5f)
                    .alwaysEdible()

                    // Positive - intelligence / stability
                    .effect(() -> new MobEffectInstance(
                                    MobEffects.SATURATION,
                                    200 + (int) (Math.random() * 401)),
                            0.10f + (float) (Math.random() * 0.51f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.DIG_SPEED,
                                    200 + (int) (Math.random() * 401)),
                            0.10f + (float) (Math.random() * 0.51f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.DAMAGE_RESISTANCE,
                                    200 + (int) (Math.random() * 401)),
                            0.10f + (float) (Math.random() * 0.51f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.NIGHT_VISION,
                                    200 + (int) (Math.random() * 401)),
                            0.10f + (float) (Math.random() * 0.51f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.REGENERATION,
                                    200 + (int) (Math.random() * 401)),
                            0.10f + (float) (Math.random() * 0.51f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.SLOW_FALLING,
                                    200 + (int) (Math.random() * 401)),
                            0.10f + (float) (Math.random() * 0.51f))

                    // Negative - mental / physical fatigue
                    .effect(() -> new MobEffectInstance(
                                    MobEffects.WEAKNESS,
                                    100 + (int) (Math.random() * 201)),
                            0.10f + (float) (Math.random() * 0.61f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.MOVEMENT_SLOWDOWN,
                                    100 + (int) (Math.random() * 201)),
                            0.10f + (float) (Math.random() * 0.51f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.DIG_SLOWDOWN,
                                    100 + (int) (Math.random() * 201)),
                            0.10f + (float) (Math.random() * 0.51f))

                    .build();


    // =========================================================
    // RAINPOWDER - LIGHT / THIN / CLOUD
    // =========================================================

    public static final FoodProperties RAINPOWDER =
            new FoodProperties.Builder()
                    .nutrition(3)
                    .saturationModifier(0.5f)
                    .alwaysEdible()

                    // Positive - light / airy
                    .effect(() -> new MobEffectInstance(
                                    MobEffects.INVISIBILITY,
                                    200 + (int) (Math.random() * 401)),
                            0.10f + (float) (Math.random() * 0.51f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.SATURATION,
                                    200 + (int) (Math.random() * 401)),
                            0.10f + (float) (Math.random() * 0.51f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.MOVEMENT_SPEED,
                                    200 + (int) (Math.random() * 401)),
                            0.10f + (float) (Math.random() * 0.51f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.JUMP,
                                    200 + (int) (Math.random() * 401)),
                            0.10f + (float) (Math.random() * 0.51f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.SLOW_FALLING,
                                    200 + (int) (Math.random() * 401)),
                            0.10f + (float) (Math.random() * 0.51f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.WATER_BREATHING,
                                    200 + (int) (Math.random() * 401)),
                            0.10f + (float) (Math.random() * 0.51f))

                    // Negative - unpredictable weather
                    .effect(() -> new MobEffectInstance(
                                    MobEffects.LEVITATION,
                                    100 + (int) (Math.random() * 201)),
                            0.10f + (float) (Math.random() * 0.61f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.CONFUSION,
                                    100 + (int) (Math.random() * 201)),
                            0.10f + (float) (Math.random() * 0.41f))

                    .effect(() -> new MobEffectInstance(
                                    MobEffects.DARKNESS,
                                    100 + (int) (Math.random() * 201)),
                            0.10f + (float) (Math.random() * 0.61f))

                    .build();


    // =========================================================
    // ROSE APPLE - REFINED ROSPOWDER
    // =========================================================

    public static final FoodProperties ROSE_APPLE =
            new FoodProperties.Builder()
                    .nutrition(7)
                    .saturationModifier(2.5f)
                    .alwaysEdible()

                    .effect(() -> new MobEffectInstance(
                            MobEffects.SATURATION, 6000), 1.0f)

                    .effect(() -> new MobEffectInstance(
                            MobEffects.MOVEMENT_SPEED, 6000), 1.0f)

                    .effect(() -> new MobEffectInstance(
                            MobEffects.JUMP, 6000), 1.0f)

                    .effect(() -> new MobEffectInstance(
                            MobEffects.FIRE_RESISTANCE, 6000), 1.0f)

                    .effect(() -> new MobEffectInstance(
                            MobEffects.REGENERATION, 6000), 1.0f)

                    .effect(() -> new MobEffectInstance(
                            MobEffects.DAMAGE_BOOST, 6000), 1.0f)

                    .effect(() -> new MobEffectInstance(
                            MobEffects.GLOWING, 6000), 1.0f)

                    .build();


    // =========================================================
    // GIN APPLE - REFINED GINPOWDER
    // =========================================================

    public static final FoodProperties GIN_APPLE =
            new FoodProperties.Builder()
                    .nutrition(7)
                    .saturationModifier(2.5f)
                    .alwaysEdible()

                    .effect(() -> new MobEffectInstance(
                            MobEffects.SATURATION, 6000), 1.0f)

                    .effect(() -> new MobEffectInstance(
                            MobEffects.DIG_SPEED, 6000), 1.0f)

                    .effect(() -> new MobEffectInstance(
                            MobEffects.DAMAGE_RESISTANCE, 6000), 1.0f)

                    .effect(() -> new MobEffectInstance(
                            MobEffects.NIGHT_VISION, 6000), 1.0f)

                    .effect(() -> new MobEffectInstance(
                            MobEffects.REGENERATION, 6000), 1.0f)

                    .effect(() -> new MobEffectInstance(
                            MobEffects.SLOW_FALLING, 6000), 1.0f)

                    .effect(() -> new MobEffectInstance(
                            MobEffects.GLOWING, 6000), 1.0f)

                    .build();


    // =========================================================
    // RAIN APPLE - REFINED RAINPOWDER
    // =========================================================

    public static final FoodProperties RAIN_APPLE =
            new FoodProperties.Builder()
                    .nutrition(7)
                    .saturationModifier(2.5f)
                    .alwaysEdible()

                    .effect(() -> new MobEffectInstance(
                            MobEffects.INVISIBILITY, 6000), 1.0f)

                    .effect(() -> new MobEffectInstance(
                            MobEffects.SATURATION, 6000), 1.0f)

                    .effect(() -> new MobEffectInstance(
                            MobEffects.MOVEMENT_SPEED, 6000), 1.0f)

                    .effect(() -> new MobEffectInstance(
                            MobEffects.JUMP, 6000), 1.0f)

                    .effect(() -> new MobEffectInstance(
                            MobEffects.SLOW_FALLING, 6000), 1.0f)

                    .effect(() -> new MobEffectInstance(
                            MobEffects.WATER_BREATHING, 6000), 1.0f)

                    .effect(() -> new MobEffectInstance(
                            MobEffects.GLOWING, 6000), 1.0f)

                    .build();


    // =========================================================
    // NYLI APPLE - REFINED NYLIPOWDER
    // =========================================================

    public static final FoodProperties NYLI_APPLE =
            new FoodProperties.Builder()
                    .nutrition(7)
                    .saturationModifier(2.5f)
                    .alwaysEdible()

                    .effect(() -> new MobEffectInstance(
                            MobEffects.INVISIBILITY, 6000), 1.0f)

                    .effect(() -> new MobEffectInstance(
                            MobEffects.NIGHT_VISION, 6000), 1.0f)

                    .effect(() -> new MobEffectInstance(
                            MobEffects.LEVITATION, 6000), 1.0f)

                    .effect(() -> new MobEffectInstance(
                            MobEffects.SLOW_FALLING, 6000), 1.0f)

                    .effect(() -> new MobEffectInstance(
                            MobEffects.GLOWING, 6000), 1.0f)

                    .build();

}